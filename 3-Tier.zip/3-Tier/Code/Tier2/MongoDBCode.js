const express = require("express");
const app = express();
require("dotenv").config()

const mongoose = require("mongoose");
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended: true}));

const path = require('path');
const parentDir = path.dirname(__dirname);

// Lets you access multiple HTML files
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.set('views', __dirname);

mongoose.connect("mongodb+srv://aidendatabase:CarOverwatch75@cluster0.awzjjvh.mongodb.net/?retryWrites=true&w=majority", {useNewUrlParser: true}, {useUnifiedTopology: true},)

app.use(express.static('public'));

console.log("Connected To MongoDB Database!")

//create data schema
const aidenSchema = {
    name: String,
    module_1: String,
    module_1_result: Number,
    module_2: String,
    module_2_result: Number,
    module_3: String,
    module_3_result: Number
}

var Aiden = mongoose.model("Aiden", aidenSchema);

// Pages
// View Database
app.get('/leacture', (req, res) => {
    Aiden.find({}, function(err, aidens) {
        res.render(parentDir + '/Tier1/leacture.ejs', {
            aidensList: aidens
        })
    })
})

// Add-Enrol Student
app.get('/student', (req,res) => {
    res.render(parentDir + '/Tier1/student.html');
   });

// Main Page
app.get("/", function(req, res) {
    res.render(parentDir + "/Tier1/landing.html")
})

// For Student
app.post("/", function(req, res) {
    let newAiden = new Aiden({
        name: req.body.name,
        module_1: req.body.module_1,
        module_1_result: req.body.module_1_result,
        module_2: req.body.module_2,
        module_2_result: req.body.module_2_result,
        module_3: req.body.module_3,
        module_3_result: req.body.module_3_result
    })
    newAiden.save();
    res.redirect('/'); // redirects to student
})

// Creates ID Page Links
// Just for testing, disregard
function myfun() {
    Aiden.find({}, function(err, aidens) {
        aidens.forEach(aidens => {
            var myb = "/" + aidens._id
            console.log(myb)
            var fs = require('fs');
            var htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Page 1</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link type="css" rel="stylesheet" href="styles.css">
    </head>
    <body>
      <h1>H1 Header</h1>
      <% var x = "hi" %>
      <h2><%= aidensList._id %></h2>
      <h2><%= aidensList.name %></h2>
      <h2><%= aidensList.module_1 %></h2>
      <h2><%= aidensList.module_1_result %></h2>
      <h2><%= aidensList.module_2 %></h2>
      <h2><%= aidensList.module_2_result %></h2>
      <h2><%= aidensList.module_3 %></h2>
      <h2><%= aidensList.module_3_result %></h2>
      
    </body>
    </html>
            `;
            fs.writeFileSync('./' + myb + '.ejs', htmlContent, (err) => {} );
            app.get(myb, (req, res) => {
                res.render('./' + myb + '.ejs', {aidensList: aidens});
            })
        })
    })
}

// Ports
const PORT = process.env.PORT || 3000

app.listen(3000, ()=> {
    console.log("server is running on port:",PORT);
})