const express = require('express')
const mysql = require('mysql2');
const app = express();

app.use(express.json());
app.use(express.static('public'));
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));

const path = require('path');
const parentDir = path.dirname(__dirname);

// Lets you access multiple HTML files
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.set('views', __dirname);

const PORT = process.env.PORT || 3000
app.listen(3000, ()=> {
  console.log("Server is running on port:",PORT);
})

///////////////////////////////////////////////////////

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "aiden",
  password: "password",
  database: "aidendatabase"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected To MySQL Database!");
});

///////////////////////////////////////////////////////

// Pages
// Landing

app.get('/', (req,res) => {
  res.render(parentDir + "/Tier1/landing.html");
});

// Leacture

app.get('/leacture', function(req, res, next) {
  var sql='SELECT * FROM StudentTable';
  con.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.render(parentDir + '/Tier1/leacture.ejs', { title: 'User List', aidensList: data});
  });
});
module.exports = app;

// Student

app.get('/student', (req,res) => {
  res.render(parentDir + '/Tier1/student.html');
});

app.post("/", function(req, res, next) {
  var name = req.body.name;
  var module_1 = req.body.module_1;
  var module_1_result = req.body.module_1_result;
  var module_2 = req.body.module_2;
  var module_2_result = req.body.module_2_result;
  var module_3 = req.body.module_3;
  var module_3_result = req.body.module_3_result;
  var sql = "INSERT INTO StudentTable (name, module_1, module_1_result, module_2, module_2_result, module_3, module_3_result) VALUES ('"+name+"', '"+module_1+"', '"+module_1_result+"', '"+module_2+"', '"+module_2_result+"', '"+module_3+"', '"+module_3_result+"')";
  console.log("-------->",req.body.name)
  con.query(sql);
  res.redirect('/');
})



//
//
//
// Functions
function Create_Table() {
  var sql = "CREATE TABLE `aidendatabase`.`StudentTable` (`name` TEXT, `module_1` TEXT, `module_1_result` TINYINT, `module_2` TEXT, `module_2_result` TINYINT, `module_3` TEXT, `module_3_result` TINYINT);";
  con.query(sql)
  console.log("Table Created")
}

function Insert_Into_Table(var1, var2, var3, var4, var5, var6, var7) {
  var name = "Tester"
  var module_1 = "Science"
  var module_1_result = 55
  var module_2 = "English"
  var module_2_result = 22
  var module_3 = "Maths"
  var module_3_result = 33
  var sql = "INSERT INTO StudentTable (name, module_1, module_1_result, module_2, module_2_result, module_3, module_3_result) VALUES ('"+name+"', '"+module_1+"', '"+module_1_result+"', '"+module_2+"', '"+module_2_result+"', '"+module_3+"', '"+module_3_result+"')";
  con.query(sql)
  console.log("Inserted Into Table")
}